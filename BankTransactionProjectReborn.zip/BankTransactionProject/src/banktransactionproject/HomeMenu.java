package banktransactionproject;
import java.io.IOException;
import java.util.*;
import banktransactionproject.transactions.*;



public class HomeMenu {
	
	public static void main(String args[])throws IOException{
		try {
			
			
			User U=new User();
			//Update Up= new Update();
			int choice;
			char a='n';
			Scanner scan=new Scanner(System.in);
			System.out.println("----------------------------------------");
			System.out.println("                 Welcome                ");
			System.out.println("                   To                   ");
			System.out.println("                Java Bank               ");
			System.out.println("----------------------------------------");
			
			do {
				
				a='n';
				
				System.out.println("\nPlease enter your Choice");
				System.out.println("1.Create new Account");
				System.out.println("2.Existing Account");
				System.out.println("3.Delete Account");
				//System.out.println("4.Update Account");
				System.out.println("5.Exit Banking System");
				choice=scan.nextInt();
				System.out.println("----------------------------------------");
				
				if(choice>5 || choice<1) {
					System.out.println("Wrong Choice Entered");
					System.out.println("----------------------------------------");
					System.out.println("Do you wish to Continue(Y/N):");
					a=scan.next().charAt(0);
					System.out.println("----------------------------------------");
					
				}
				else {
					break;
				}
				
			}while(a=='Y'||a=='y');
			
			switch(choice) {
			case 1:
				U.NewUser();
				break;
			case 2:
				U.ExistingUser();
				break;
			case 3:
				U.DeleteAccount();
				break;
			/*case 4:
				Up.UpdateUser();
				break;*/
			case 5:
				System.out.println("Thank You");
				System.out.println("----------------------------------------");
				break;
			}
		}
		
		catch(InputMismatchException a) {
			System.out.println("----------------------------------------");
			System.out.println("                  OOPS                  ");
			System.out.println("      You have entered wrong input!     ");
			System.out.println("----------------------------------------");
		}
		catch(Exception e) {}
	}
}
