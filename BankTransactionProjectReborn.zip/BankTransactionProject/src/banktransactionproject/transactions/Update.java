//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.InputMismatchException;
//import java.util.Scanner;

/*Scanner scan= new Scanner(System.in);
		int count=0;
		String name=null,pass=null,amt=null,cont-null,actype=null;
		System.out.println("Enter your Name:");
		String uname=scan.next();
		System.out.println("Enter your pin number:");
		String upass=scan.next();
		
		String userpass=uname+" "+upass;
		char cnt=" ";
		int choice;
		String line,line2,fullname;
		char full[]=new char[100];
		
		try {
		
			BufferedReader ins= new BufferedReader(new FileReader("userdetails.txt"));
			
			while((line=ins.readLine())!=null) {
				
				if(line.contains(userpass)) {
					
					System.out.println("\nLogged in Successfully !!!");
					System.out.println("----------------------------------------");
					BufferedReader nmf= new BufferedReader(new FileReader("name.txt"));
					
					while((line2=nmf.readLine())!=null) {
						
						if(line2.contains(userpass)) {
							
							line2.getChars(13,line2.length(),full,0);
							fullname=String.valueOf(full).trim();
							System.out.println("\n\tWelcome Dear,"+fullname);		
						}
					}
					nmf.close();
					
					line.getChars(12,18,account,0);
					String ac=String.valueOf(account).trim();
					String userac=uname+" "+ac;
					
					do {
						
						System.out.println("----------------------------------------");
						System.out.println("\nPlease Enter Your Choice :");
						System.out.println("1.Deposit");						
						System.out.println("2.Withdraw");
						System.out.println("3.Balance Enquiry");
						System.out.println("4.Mini Statement");
						choice=scan.nextInt();
						
						switch(choice) {
							
						case 1:
							ins.close();
							deposit(userpass);
							break;
						case 2:
							ins.close();
							withdraw(userpass);
							break;
						case 3:
							ins.close();
							inquery(userpass);
							break;
						case 4:
							ins.close();
							statement(userpass);
							break;
						default:
							System.out.println("----------------------------------------");
							System.out.println("                  OOPS                  ");
							System.out.println("      You have entered wrong input!     ");
							System.out.println("----------------------------------------");
							break;
						}
						System.out.println("Do you wish to Continue(y/n):");
						cnt=scan.next().charAt(0);
					
					}while(cnt=='y'||cnt=='n');
					
					if(cnt=='y'||cnt=='n') {
						System.out.println("----------------------------------------");
						System.out.println("      Thank you for banking With us"     );
						System.out.println("----------------------------------------");
					}
					count=1;
					break;
				}
			}
			if(count==0) {
		
				System.out.println("----------------------------------------");
				System.out.println("                  OOPS                  ");
				System.out.println("   You have entered wrong user/pass     ");
				System.out.println("----------------------------------------");
			}
			ins.close();
			
		}
		
		catch(InputMismatchException e) {
			
			System.out.println("----------------------------------------");
			System.out.println("                  OOPS                  ");
			System.out.println("      You have entered wrong input!     ");
			System.out.println("----------------------------------------");
		
		}
		catch(Exception e) {
			
		}*/