package banktransactionproject.transactions;
import banktransactionproject.*;
import java.util.*;

import javax.annotation.processing.Filer;
import javax.lang.model.element.Element;
import javax.tools.FileObject;
import javax.tools.JavaFileObject;
import javax.tools.JavaFileManager.Location;

import java.io.*;
import java.text.SimpleDateFormat;


public class User extends Operations{
	
	String name,actype,ac,contact,pass;
	float amount;
	String amnt;
	Scanner scanner=new Scanner(System.in);
	char acnumber[]=new char[6];
	char pin[]=new char[5];
	
	public void NewUser() {
		int c=0;
		String line;
		String lread;
		char nm[]=new char[6];
		
		System.out.println(" \t\tEnter your Details:");
		System.out.println("----------------------------------------");
		
		try {
			
			PrintWriter outs = null;
			try {
				outs = new PrintWriter(new FileWriter("userdetails.txt",true));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BufferedWriter bw = null;
			try {
				bw = new BufferedWriter(new FileWriter("statement.txt",true));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			do {
				
				c=0;
				System.out.println("Enter Your Full Name:");
				name=scanner.nextLine().trim();
				if(name.length()<3) {
					System.out.println("Should be more than 3 characters");
					c++;
				}
				
			}while(c==1);
			
			
			System.out.println("----------------------------------------");
			
			
			do {
				c=0;
				System.out.println("Enter Your Contact No:");
				contact=scanner.next();
				/*if(name.length()!=10) {
					System.out.println("Enter valid contact");
					c++;
				}
				else {
					// contact already exist code.
				}*/
				
			}while(c==1);
			
			
			System.out.println("----------------------------------------");
			
			
			do {
				c=0;
				System.out.println("Enter Initial Amount:");
				amnt=scanner.next();
				amount=Float.parseFloat(amnt);
				if(amount<1000) {
					System.out.println("Initial amount should be greater than 1000/-");
					c++;
				}
				
			}while(c==1);
			
			
			System.out.println("----------------------------------------");
			
			
			do {
				
				System.out.println("Enter Account Type(Savings or Current):");
				ac=scanner.next();
				actype=ac.toLowerCase();
				
				if(!(actype.equals("savings")||actype.equals("current"))) {
					System.out.println("Account type should be 'Savings' or 'Current'");
					c++;
				}	
				
			}while(!(actype.equals("savings")||actype.equals("current")));
			
			
			if (actype.equals("savings")) {
				actype="savings";
			}
			
			
			System.out.println();
			System.out.println("Account created successfully");
			System.out.println("----------------------------------------");
			
			
			Random rnd= new Random();
			String username;
			name.getChars(0,3,nm,0);
			username=String.valueOf(nm).trim();
			if(username.length()<2)
				username+=(10000+rnd.nextInt(90000));
			else if(username.length()<2)
				username+=(1000+rnd.nextInt(9000));
			else
				username+=(100+rnd.nextInt(900));
			
			if(username.contains(" "))
				username=username.replace(" ", "a");
			
			//
			
			int acnt;
			do {
				acnt= 10000+ rnd.nextInt(90000);
				c=0;
				BufferedReader br = null;
				try {
					br = new BufferedReader(new FileReader("userdetails.txt"));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					while((lread=br.readLine())!=null) {
						
						if(lread.contains(acnt+" ")) {
							c++;
							break;
					}
					//br.close();
}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		}while(c==1);
			
			
		int pass= 1000+rnd.nextInt(9000);	
			
		System.out.println("\nUsername:"+username);
		System.out.println("Pin no:"+pass);
		System.out.println("Account Number:"+acnt);
		System.out.println("Initial Balance:"+amount);
		System.out.println("----------------------------------------");	
		
		SimpleDateFormat sdf= new SimpleDateFormat("dd/mm/yyyy hh:mm:ss");
		String date = sdf.format(new Date());
		
		try {
			bw.write(username+" "+acnt+" initial"+" "+amount+" "+date);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//statement.txt
		try {
			bw.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		outs.println(username+" "+pass+" "+acnt+" "+actype+" "+contact+" "+amount);//userdetails.txt
		outs.close();
		
		BufferedWriter wr = null;
		try {
			wr = new BufferedWriter(new FileWriter("name.txt",true));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			wr.write(username+" "+pass+" "+name);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			wr.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			wr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("----------------------------------------");
		System.out.println("\nThank you for banking With us");
		System.out.println("----------------------------------------");	
		
	}
		
	catch(InputMismatchException e) {
		
		System.out.println("----------------------------------------");
		System.out.println("                  OOPS                  ");
		System.out.println("      You have entered wrong input!     ");
		System.out.println("----------------------------------------");
	
	}
		
}
/*------------------------------------------------------------------------------------*/	

/*------------------------------------------------------------------------------------*/

/*-------------------Existing User method---------------------------------------------*/

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/
		
	
	char account[]=new char[6];
	
	public void ExistingUser() {
		
		Scanner scan= new Scanner(System.in);
		int count=0;
		String name=null,pass=null,amt=null,cont=null,actype=null;
		System.out.println("Enter your Name:");
		String uname=scan.next();
		System.out.println("Enter your pin number:");
		String upass=scan.next();
		
		String userpass=uname+" "+upass;
		char cnt;
		int choice;
		String line,line2,fullname;
		char full[]=new char[100];
		
		try {

			BufferedReader ins= new BufferedReader(new FileReader("userdetails.txt"));
			
			while((line=ins.readLine())!=null) {
				
				if(line.contains(userpass)) {
					
					System.out.println("\nLogged in Successfully !!!");
					System.out.println("----------------------------------------");
					BufferedReader nmf= new BufferedReader(new FileReader("name.txt"));
					
					while((line2=nmf.readLine())!=null) {
						
						if(line2.contains(userpass)) {
							
							line2.getChars(13,line2.length(),full,0);
							fullname=String.valueOf(full).trim();
							System.out.println("\n\tWelcome Dear,"+fullname);		
						}
					}
					nmf.close();
					
					line.getChars(12,18,account,0);
					String ac=String.valueOf(account).trim();
					String userac=uname+" "+ac;
					
					do {
						
						System.out.println("----------------------------------------");
						System.out.println("\nPlease Enter Your Choice :");
						System.out.println("1.Deposit");						
						System.out.println("2.Withdraw");
						System.out.println("3.Balance Enquiry");
						System.out.println("4.Mini Statement");
						choice=scan.nextInt();
						
						switch(choice) {
							
						case 1:
							ins.close();
							deposit(userpass);
							break;
						case 2:
							ins.close();
							withdraw(userpass);
							break;
						case 3:
							ins.close();
							inquery(userpass);
							break;
						case 4:
							ins.close();
							statement(userpass);
							break;
						default:
							System.out.println("----------------------------------------");
							System.out.println("                  OOPS                  ");
							System.out.println("      You have entered wrong input!     ");
							System.out.println("----------------------------------------");
							break;
						}
						System.out.println("Do you wish to Continue(y/n):");
						cnt=scan.next().charAt(0);
					
					}while(cnt=='y'||cnt=='n');
					
					if(cnt=='y'||cnt=='n') {
						System.out.println("----------------------------------------");
						System.out.println("      Thank you for banking With us"     );
						System.out.println("----------------------------------------");
					}
					count=1;
					break;
				}
			}
			if(count==0) {

				System.out.println("----------------------------------------");
				System.out.println("                  OOPS                  ");
				System.out.println("   You have entered wrong user/pass     ");
				System.out.println("----------------------------------------");
			}
			ins.close();
			
		}
		
		catch(InputMismatchException e) {
			
			System.out.println("----------------------------------------");
			System.out.println("                  OOPS                  ");
			System.out.println("      You have entered wrong input!     ");
			System.out.println("----------------------------------------");
		
		}
		catch(Exception e) {
			
		}
	}		
/*------------------------------------------------------------------------------------*/	

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/
		
	public void DeleteAccount() {
		
		String oldFileName="userdetails.txt";
		String tmpFileName="out.txt";
		System.out.println("Enter username :");
		String uname=scanner.next();
		System.out.println("Enter pin code :");
		String upin=scanner.next();
		
		String combo=uname+" "+upin+" ";
		String data;
		int cnt=0;
		String ac=null;
		String userac=null;
		BufferedReader ins=null;
		BufferedWriter outs=null;
		
		try {
			
			ins=new BufferedReader(new FileReader(oldFileName));
			outs=new BufferedWriter(new FileWriter(tmpFileName));
			
			while((data=ins.readLine())!=null) {
				
				if(data.contains(combo)) {
					
					data.getChars(11, 17, account, 0);
					ac=String.valueOf(account).trim();
					
					cnt++;
					continue;
				
				}
				
				outs.write(data);
				outs.newLine();
			}
			userac=uname+" "+ac;
			
			if(cnt==0) {
				
				System.out.println("----------------------------------------");
				System.out.println("                  OOPS                  ");
				System.out.println("   You have entered wrong user/pass     ");
				System.out.println("----------------------------------------");
				
			}
			else {
				System.out.println("----------------------------------------");
				System.out.println("      Your Account Has Been Deleted!"    );
				System.out.println("      Thank you for banking With us"     );
				System.out.println("----------------------------------------");
			}
		}
		catch(Exception e) {
			
		}
		finally {
			
			try {
				
				if(ins!=null)
					ins.close();
			}
			catch(IOException e) {
				//
			}
			try {
				
				if(outs!=null)
					outs.close();
			}
			catch(IOException e) {
				//
			}
		}
		
		File oldFile=new File(oldFileName);
		oldFile.delete();
		
		File newFile=new File(tmpFileName);
		newFile.renameTo(oldFile);
		
		String old="statement.txt";
		String temp="delete.txt";
		
		try {
			ins=new BufferedReader(new FileReader(old));
			outs=new BufferedWriter(new FileWriter(temp));
			
			while((data=ins.readLine())!=null) {
				
				if(data.contains(userac)) {
					continue;
				}
				outs.write(data);
				outs.newLine();
			}
		}
		catch(Exception e) {
				
			}
		finally {
				try {
					if(ins!=null)
						ins.close();
				}
				catch(IOException e) {
					//
				}
				try {
					
					if(outs!=null)
						outs.close();
				}
				catch(IOException e) {
					//
				}
			}
			File oldF=new File(old);
			oldF.delete();
			
			File newF=new File(temp);
			newF.renameTo(oldF);
			
			
			
			String oldFile2="name.txt";
			String tempFile2="delete.txt";
			
			try {
				ins=new BufferedReader(new FileReader(old));
				outs=new BufferedWriter(new FileWriter(temp));
				
				while((data=ins.readLine())!=null) {
					
					if(data.contains(combo)) {
						continue;
					}
					outs.write(data);
					outs.newLine();
				}
			}
				catch(Exception e) {
					
				}
				finally {
					try {
						if(ins!=null)
							ins.close();
					}
					catch(IOException e) {
						//
					}
					try {
						
						if(outs!=null)
							outs.close();
					}
					catch(IOException e) {
						//
					}
				}
			File oldName=new File(oldFile2);
			oldName.delete();
			
			File newName=new File(tempFile2);
			newName.renameTo(oldName);
	


	}
		
}		
/*------------------------------------------------------------------------------------*/	

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------*/
